import React from 'react';
import {View,Text} from 'react-native';
import logo from '../ ../assests/images/snack-icon.png'
const Signinscreen =()=>{
  return (
    <View>
    <Image source={logo} style={styles.logo}/>
    </View>
    );
};
const styles=StyleSheet.create({
  logo:{
    width:100,
    height:100,
    
  },
}
);
export default Signinscreen;